var searchData=
[
  ['vkz_5fclear_5fcolour_70',['vkz_clear_colour',['../vkzos_8h.html#a15aa36bf5aaa3c4e44b236c9eb98e634',1,'vkzos.c']]],
  ['vkz_5finstance_71',['vkz_instance',['../vkzos_8h.html#ad0279a86c08897a13cc85b0c35b5a72e',1,'vkzos.c']]],
  ['vkz_5flogical_5fdevice_72',['vkz_logical_device',['../vkzos_8h.html#a81a8dd4066651194d34a73f25c9cc3b8',1,'vkzos.c']]],
  ['vkz_5fphysical_5fdevice_73',['vkz_physical_device',['../vkzos_8h.html#ae613ef4aa20d05a6c7a3246ceaeb8e5a',1,'vkzos.c']]],
  ['vkz_5fpipeline_5flayout_74',['vkz_pipeline_layout',['../vkzos_8h.html#a497cab2d9e5c7ae0173b26e788efd051',1,'vkzos.c']]],
  ['vkz_5fsurface_75',['vkz_surface',['../vkzos_8h.html#ae0d51c9f83acb388c4f9dbf357e74d07',1,'vkzos.c']]],
  ['vkz_5fswapchain_5fimage_5fcount_76',['vkz_swapchain_image_count',['../vkzos_8h.html#ac48c41837c8f16590c36c8b2133f8acd',1,'vkzos.c']]]
];
