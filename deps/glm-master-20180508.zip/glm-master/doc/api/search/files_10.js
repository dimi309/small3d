var searchData=
[
  ['random_2ehpp',['random.hpp',['../a00085.html',1,'']]],
  ['range_2ehpp',['range.hpp',['../a00086.html',1,'']]],
  ['raw_5fdata_2ehpp',['raw_data.hpp',['../a00087.html',1,'']]],
  ['reciprocal_2ehpp',['reciprocal.hpp',['../a00088.html',1,'']]],
  ['rotate_5fnormalized_5faxis_2ehpp',['rotate_normalized_axis.hpp',['../a00089.html',1,'']]],
  ['rotate_5fvector_2ehpp',['rotate_vector.hpp',['../a00090.html',1,'']]],
  ['round_2ehpp',['round.hpp',['../a00091.html',1,'']]]
];
