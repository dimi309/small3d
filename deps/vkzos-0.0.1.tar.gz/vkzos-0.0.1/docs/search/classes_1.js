var searchData=
[
  ['swapchain_5fsupport_5fstruct_40',['swapchain_support_struct',['../structswapchain__support__struct.html',1,'']]]
];
