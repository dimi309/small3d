vkzos
-----

A less onerous way to use the Vulkan API.