var searchData=
[
  ['news_2edox_0',['news.dox',['../news_8dox.html',1,'']]]
];
