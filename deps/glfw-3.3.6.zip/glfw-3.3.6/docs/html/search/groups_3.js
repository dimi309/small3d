var searchData=
[
  ['initialization_2c_20version_20and_20error_20reference_0',['Initialization, version and error reference',['../group__init.html',1,'']]],
  ['input_20reference_1',['Input reference',['../group__input.html',1,'']]]
];
